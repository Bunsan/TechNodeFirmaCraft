if (FML.isModLoaded("Mekanism")) {
    NEI.override("Mekanism:MachineBlock2", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
    NEI.override("Mekanism:GasTank", [100]);
    NEI.override("Mekanism:*PlasticBlock", [0]);
    NEI.override("Mekanism:Balloon", [0]);
    NEI.override("Mekanism:GlowPanel", [0]);
    NEI.override("Mekanism:PlasticFence", [0]);
}